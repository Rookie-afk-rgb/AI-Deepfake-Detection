from flask import Flask, render_template, request

import os
import cv2
import numpy as np
import tensorflow as tf

from werkzeug.utils import secure_filename

# =========================================================
# 🚀 FLASK APP
# =========================================================

app = Flask(__name__)

# =========================================================
# 📂 FOLDERS
# =========================================================

UPLOAD_FOLDER = 'static/uploads'
FFT_FOLDER = 'static/fft_outputs'

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(FFT_FOLDER, exist_ok=True)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# =========================================================
# 🧠 LOAD SAVEDMODEL
# =========================================================

print('🧠 Loading FFT SavedModel...')

model = tf.saved_model.load(
    'model/FFT_SAVEDMODEL'
)

infer = model.signatures["serving_default"]

print('✅ FFT SavedModel Loaded Successfully!')

# =========================================================
# 🔥 FFT PROCESS FUNCTION
# =========================================================

def fft_predict(image_path):

    img = cv2.imread(image_path)

    gray = cv2.cvtColor(
        img,
        cv2.COLOR_BGR2GRAY
    )

    # =====================================================
    # 🔥 FFT TRANSFORM
    # =====================================================

    fft = np.fft.fft2(gray)

    fft_shift = np.fft.fftshift(fft)

    magnitude_spectrum = 20 * np.log(
        np.abs(fft_shift) + 1
    )

    # =====================================================
    # 📡 NORMALIZE
    # =====================================================

    magnitude_spectrum = cv2.normalize(
        magnitude_spectrum,
        None,
        0,
        255,
        cv2.NORM_MINMAX
    )

    magnitude_spectrum = magnitude_spectrum.astype(np.uint8)

    # =====================================================
    # 💾 SAVE FFT IMAGE
    # =====================================================

    fft_filename = 'fft_output.png'

    fft_path = os.path.join(
        FFT_FOLDER,
        fft_filename
    )

    cv2.imwrite(
        fft_path,
        magnitude_spectrum
    )

    # =====================================================
    # 🎨 CONVERT TO RGB
    # =====================================================

    fft_rgb = cv2.cvtColor(
        magnitude_spectrum,
        cv2.COLOR_GRAY2RGB
    )

    fft_rgb = cv2.resize(
        fft_rgb,
        (224, 224)
    )

    fft_array = np.expand_dims(
        fft_rgb,
        axis=0
    )

    fft_array = fft_array.astype(np.float32)

    # =====================================================
    # 🧠 MODEL PREDICTION
    # =====================================================

    prediction = infer(
        tf.convert_to_tensor(fft_array)
    )

    prediction = list(
        prediction.values()
    )[0].numpy()[0][0]

    return prediction, fft_filename

# =========================================================
# 🏠 HOME ROUTE
# =========================================================

@app.route('/')

def home():

    return render_template('index.html')

# =========================================================
# 📤 PREDICTION ROUTE
# =========================================================

@app.route('/predict', methods=['POST'])


def predict():

    if 'file' not in request.files:

        return 'No file uploaded'

    file = request.files['file']

    if file.filename == '':

        return 'No selected file'

    filename = secure_filename(file.filename)

    filepath = os.path.join(
        app.config['UPLOAD_FOLDER'],
        filename
    )

    file.save(filepath)

    extension = filename.split('.')[-1].lower()

    # =====================================================
    # 🖼 IMAGE DETECTION
    # =====================================================

    if extension in ['jpg', 'jpeg', 'png']:

        prediction, fft_image = fft_predict(filepath)

    # =====================================================
    # 🎥 VIDEO DETECTION
    # =====================================================

    elif extension in ['mp4', 'avi', 'mov']:

        cap = cv2.VideoCapture(filepath)

        predictions = []

        frame_count = 0

        fft_image = None

        while True:

            ret, frame = cap.read()

            if not ret:
                break

            frame_count += 1

            # analyze every 15th frame
            if frame_count % 15 != 0:
                continue

            frame_path = os.path.join(
                UPLOAD_FOLDER,
                f'frame_{frame_count}.jpg'
            )

            cv2.imwrite(frame_path, frame)

            pred, fft_image = fft_predict(frame_path)

            predictions.append(pred)

        cap.release()

        if len(predictions) == 0:

            return 'Could not analyze video'

        prediction = np.mean(predictions)

    else:

        return 'Unsupported file format'

    # =====================================================
    # 📊 FINAL RESULT
    # =====================================================

    if prediction > 0.35:

        result = 'DEEPFAKE DETECTED'

        confidence = round(
            prediction * 100,
            2
        )

        color = 'red'

    else:

        result = '🟢 REAL CONTENT'

        confidence = round(
            (1 - prediction) * 100,
            2
        )

        color = 'lightgreen'

    return render_template(

        'index.html',

        uploaded_image=filename,

        fft_image=fft_image,

        result=result,

        confidence=confidence,

        color=color
    )

# =========================================================
# 🚀 RUN APP
# =========================================================

if __name__ == '__main__':

    app.run(debug=True)